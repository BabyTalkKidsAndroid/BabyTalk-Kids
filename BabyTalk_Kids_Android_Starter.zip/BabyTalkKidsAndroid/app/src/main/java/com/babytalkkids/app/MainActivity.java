package com.babytalkkids.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView status, heard, babyReply;
    private Button startButton, stopButton, languageButton;
    private boolean running = false, speaking = false, ttsReady = false;
    private String language = "mr-IN";
    private final int MIC_REQ = 42;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(109,66,207));
        buildUi();
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            if (ttsReady) { tts.setLanguage(Locale.forLanguageTag(language)); tts.setSpeechRate(0.88f); tts.setPitch(1.18f); }
        });
        if (Build.VERSION.SDK_INT < 31) status.setText("या आवृत्तीसाठी Android 12 किंवा पुढील आवृत्ती आवश्यक आहे.");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(22)); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(255,248,253));
        TextView title = new TextView(this); title.setText("🌈 BabyTalk Kids"); title.setTextSize(28); title.setTypeface(null, Typeface.BOLD); title.setTextColor(Color.rgb(83,48,150));
        root.addView(title, matchWrap());
        TextView sub = new TextView(this); sub.setText("माझ्याशी बोलूया!"); sub.setTextSize(20); sub.setTextColor(Color.DKGRAY); sub.setGravity(Gravity.CENTER); root.addView(sub, matchWrap());
        TextView baby = new TextView(this); baby.setText("👶🏻\n💗"); baby.setTextSize(70); baby.setGravity(Gravity.CENTER); root.addView(baby, new LinearLayout.LayoutParams(-1, dp(180)));
        status = makeText("पालकांची परवानगी मिळाल्यावर ऐकणे सुरू होईल.", 16); root.addView(status, matchWrap());
        heard = makeText("मूल काय बोलले: —", 18); root.addView(heard, matchWrap());
        babyReply = makeText("Baby चे उत्तर: —", 20); babyReply.setTextColor(Color.rgb(92,48,160)); root.addView(babyReply, matchWrap());
        languageButton = new Button(this); languageButton.setText("भाषा: मराठी (बदलण्यासाठी टॅप करा)"); languageButton.setOnClickListener(v -> { language = language.equals("mr-IN") ? "en-IN" : "mr-IN"; languageButton.setText(language.equals("mr-IN") ? "भाषा: मराठी (बदलण्यासाठी टॅप करा)" : "Language: English (tap to change)"); if (ttsReady) tts.setLanguage(Locale.forLanguageTag(language)); }); root.addView(languageButton, matchWrap());
        startButton = new Button(this); startButton.setText("ऐकणे सुरू करा"); startButton.setOnClickListener(v -> requestAndStart()); root.addView(startButton, matchWrap());
        stopButton = new Button(this); stopButton.setText("थांबवा / Pause"); stopButton.setOnClickListener(v -> stopListening()); root.addView(stopButton, matchWrap());
        TextView privacy = makeText("पालक नियंत्रण: ऐकणे फक्त अॅप उघडे असताना. कधीही Pause/Stop करा. आवाज सर्व्हरवर पाठवला जात नाही; ऑन-डिव्हाइस ओळख उपलब्ध असल्यासच ऑफलाइन चालेल.", 13); root.addView(privacy, matchWrap());
        setContentView(root);
    }
    private TextView makeText(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(55,45,65)); t.setPadding(0, dp(12), 0, dp(12)); t.setGravity(Gravity.CENTER); return t; }
    private LinearLayout.LayoutParams matchWrap() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(6); return p; }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private void requestAndStart() {
        if (Build.VERSION.SDK_INT < 31) { status.setText("Android 12+ आवश्यक."); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ); return; }
        startListening();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if (r == MIC_REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startListening(); else status.setText("मायक्रोफोन परवानगी आवश्यक आहे."); }

    private void startListening() {
        if (running) return;
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) { status.setText("या फोनमध्ये On-device Speech Recognition उपलब्ध नाही. ऑफलाइन Repeat सुरू होऊ शकत नाही."); return; }
        try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { status.setText("🎤 ऐकत आहे... बोला!"); }
                public void onBeginningOfSpeech() { status.setText("ऐकत आहे..."); }
                public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() { status.setText("समजून घेत आहे..."); }
                public void onError(int e) { if (running && !speaking) restartListening(); }
                public void onResults(Bundle b) { ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if (a != null && !a.isEmpty()) repeat(a.get(0)); else restartListening(); }
                public void onPartialResults(Bundle b) {} public void onEvent(int e, Bundle b) {}
            });
            running = true; startButton.setEnabled(false); listenOnce();
        } catch (Exception ex) { status.setText("आवाज ओळख सुरू झाली नाही: " + ex.getMessage()); running = false; }
    }
    private void listenOnce() {
        if (!running || recognizer == null || speaking) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try { recognizer.startListening(i); } catch (Exception e) { restartListening(); }
    }
    private void repeat(String words) {
        if (!running || words == null || words.trim().isEmpty()) { restartListening(); return; }
        speaking = true; heard.setText("मूल बोलले: " + words); babyReply.setText("Baby म्हणते: " + words);
        if (ttsReady) {
            tts.setLanguage(Locale.forLanguageTag(language));
            tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) { runOnUiThread(() -> { speaking = false; restartListening(); }); }
                @Override public void onError(String id) { runOnUiThread(() -> { speaking = false; restartListening(); }); }
            });
            tts.speak(words, TextToSpeech.QUEUE_FLUSH, null, "repeat-" + System.currentTimeMillis());
        } else { speaking = false; restartListening(); }
    }
    private void restartListening() { if (!running) return; if (recognizer != null) { try { recognizer.cancel(); } catch(Exception ignored) {} } status.postDelayed(this::listenOnce, 450); }
    private void stopListening() { running = false; speaking = false; if (recognizer != null) { try { recognizer.cancel(); recognizer.destroy(); } catch(Exception ignored) {} recognizer = null; } if (tts != null) tts.stop(); startButton.setEnabled(true); status.setText("ऐकणे थांबवले आहे."); }
    @Override protected void onPause() { super.onPause(); stopListening(); }
    @Override protected void onDestroy() { stopListening(); if (tts != null) tts.shutdown(); super.onDestroy(); }
}
