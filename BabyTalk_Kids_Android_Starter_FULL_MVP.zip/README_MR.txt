BabyTalk Kids - Android starter project

हे पहिल्या Android prototype चे source project आहे. हे अजून Play Store release किंवा पूर्ण BabyTalk Kids app नाही.

सध्याच्या prototype मध्ये:
- पालकांनी microphone permission दिल्यावर app उघडे असताना automatic listening
- Android 12+ वरील on-device SpeechRecognizer उपलब्ध असल्यास शब्द ओळखणे
- ओळखलेले शब्द फोनच्या Text-to-Speech ने पुन्हा बोलणे
- मराठी/इंग्रजी भाषा बदल
- Pause/Stop
- आवाज सर्व्हरवर पाठवणारा कोड नाही

महत्त्वाच्या मर्यादा:
- फोनमध्ये on-device speech recognition आणि संबंधित भाषा मॉडेल उपलब्ध असणे आवश्यक आहे.
- Android SpeechRecognizer ची offline उपलब्धता फोन/OS/भाषेनुसार बदलते. Google Gboard offline dictation काम करते म्हणून दुसऱ्या अॅपमध्येही API हमखास चालेल असे नाही.
- सध्याचा आवाज फोनचा TTS आवाज आहे; खास AI baby voice नाही.
- हा फक्त voice-repeat prototype आहे. Subscription, lessons, parental dashboard, store billing, ads आणि full offline content अजून जोडलेले नाही.
- मुलांचे बोलणे ऐकण्यापूर्वी पालकांची स्पष्ट परवानगी आवश्यक. अॅप background मध्ये ऐकत नाही; app pause/close झाल्यावर listening बंद होते.

APK build (GitHub Actions):
1. हा पूर्ण folder GitHub repository मध्ये upload करा.
2. Repository च्या Actions tab मध्ये जाऊन Build BabyTalk Kids APK workflow चालवा.
3. Workflow पूर्ण झाल्यावर Artifacts मधून BabyTalk-Kids-debug-apk डाउनलोड करा.

Package: com.babytalkkids.app
Min Android: Android 12 (API 31)
