package com.babytalkkids.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView status, heard, babyReply;
    private Button startButton, stopButton, languageButton;
    private boolean running = false, speaking = false, ttsReady = false;
    private String language = "mr-IN";
    private final int MIC_REQ = 42;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(109,66,207));
        buildUi();
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            if (ttsReady) { tts.setLanguage(Locale.forLanguageTag(language)); tts.setSpeechRate(0.88f); tts.setPitch(1.18f); }
        });
        if (Build.VERSION.SDK_INT < 31) status.setText("या आवृत्तीसाठी Android 12 किंवा पुढील आवृत्ती आवश्यक आहे.");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(22)); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(255,248,253));
        TextView title = new TextView(this); title.setText("🌈 BabyTalk Kids"); title.setTextSize(28); title.setTypeface(null, Typeface.BOLD); title.setTextColor(Color.rgb(83,48,150));
        root.addView(title, matchWrap());
        TextView sub = new TextView(this); sub.setText("माझ्याशी बोलूया!"); sub.setTextSize(20); sub.setTextColor(Color.DKGRAY); sub.setGravity(Gravity.CENTER); root.addView(sub, matchWrap());
        ImageView babyPhoto = new ImageView(this);
        babyPhoto.setImageResource(com.babytalkkids.app.R.drawable.baby_girl);
        babyPhoto.setContentDescription("BabyTalk Kids AI Baby Girl");
        babyPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        babyPhoto.setBackgroundColor(Color.rgb(255,235,239));
        LinearLayout.LayoutParams photoParams = new LinearLayout.LayoutParams(-1, dp(270));
        photoParams.topMargin = dp(12); photoParams.bottomMargin = dp(12);
        root.addView(babyPhoto, photoParams);
        status = makeText("पालकांची परवानगी मिळाल्यावर ऐकणे सुरू होईल.", 16); root.addView(status, matchWrap());
        heard = makeText("मूल काय बोलले: —", 18); root.addView(heard, matchWrap());
        babyReply = makeText("Baby चे उत्तर: —", 20); babyReply.setTextColor(Color.rgb(92,48,160)); root.addView(babyReply, matchWrap());
        languageButton = new Button(this); languageButton.setText("भाषा: मराठी (बदलण्यासाठी टॅप करा)"); languageButton.setOnClickListener(v -> { language = language.equals("mr-IN") ? "en-IN" : "mr-IN"; languageButton.setText(language.equals("mr-IN") ? "भाषा: मराठी (बदलण्यासाठी टॅप करा)" : "Language: English (tap to change)"); if (ttsReady) tts.setLanguage(Locale.forLanguageTag(language)); }); root.addView(languageButton, matchWrap());
        startButton = new Button(this); startButton.setText("ऐकणे सुरू करा"); startButton.setOnClickListener(v -> requestAndStart()); root.addView(startButton, matchWrap());
        stopButton = new Button(this); stopButton.setText("थांबवा / Pause"); stopButton.setOnClickListener(v -> stopListening()); root.addView(stopButton, matchWrap());
        TextView lessonsTitle = makeText("🎓 चला शिकूया!", 22); lessonsTitle.setTypeface(null, Typeface.BOLD); root.addView(lessonsTitle, matchWrap());
        addLessonButton(root, "🔤 मराठी स्वर", "अ आ इ ई उ ऊ ऋ ए ऐ ओ औ अं अः");
        addLessonButton(root, "📝 मराठी व्यंजने", "क ख ग घ ङ च छ ज झ ञ ट ठ ड ढ ण त थ द ध न प फ ब भ म य र ल व श ष स ह ळ क्ष ज्ञ");
        addLessonButton(root, "📚 बाराखडी", "क का कि की कु कू के कै को कौ कं कः");
        addLessonButton(root, "🇬🇧 English ABC", "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z");
        addLessonButton(root, "🐾 प्राणी", "गाय, कुत्रा, मांजर, सिंह, हत्ती, घोडा, माकड");
        addLessonButton(root, "🍎 फळे", "आंबा, सफरचंद, केळी, द्राक्षे, संत्रे, पेरू");
        addLessonButton(root, "🎨 रंग", "लाल, निळा, पिवळा, हिरवा, गुलाबी, जांभळा");
        addLessonButton(root, "🔢 अंक", "एक, दोन, तीन, चार, पाच, सहा, सात, आठ, नऊ, दहा");
        addLessonButton(root, "👨‍👩‍👧 कुटुंब", "आई, बाबा, आजी, आजोबा, दादा, ताई, काका, काकू, मामा, मामी");
        addLessonButton(root, "😊 चांगले शब्द", "नमस्कार, धन्यवाद, कृपया, माफ करा, शुभ रात्री");
        TextView privacy = makeText("पालक नियंत्रण: ऐकणे फक्त अॅप उघडे असताना. कधीही Pause/Stop करा. फोनची Speech सेवा वापरली जाते. Offline पर्याय उपलब्ध असल्यासच इंटरनेटशिवाय चालेल; फोन/भाषेनुसार बदलू शकते.", 13); root.addView(privacy, matchWrap());
        android.widget.ScrollView scroll = new android.widget.ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
    }

    private void addLessonButton(LinearLayout root, String label, String words) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> {
            babyReply.setText("Baby शिकवते: " + words);
            if (ttsReady) { tts.stop(); tts.setLanguage(Locale.forLanguageTag(language)); tts.speak(words, TextToSpeech.QUEUE_FLUSH, null, "lesson-" + System.currentTimeMillis()); }
            status.setText("धडा सुरू आहे. ऐका आणि मुलासोबत पुन्हा म्हणा.");
        });
        root.addView(b, matchWrap());
    }

    private TextView makeText(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(55,45,65)); t.setPadding(0, dp(12), 0, dp(12)); t.setGravity(Gravity.CENTER); return t; }
    private LinearLayout.LayoutParams matchWrap() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(6); return p; }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private void requestAndStart() {
        if (Build.VERSION.SDK_INT < 31) { status.setText("Android 12+ आवश्यक."); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ); return; }
        startListening();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if (r == MIC_REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startListening(); else status.setText("मायक्रोफोन परवानगी आवश्यक आहे."); }

    private void startListening() {
        if (running) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("या फोनमध्ये Speech Recognition सेवा उपलब्ध नाही. Google app/भाषा सेवा तपासा.");
            return;
        }
        try {
            // Use the phone's installed recognition service and request offline processing when supported.
            // Android services may ignore the offline preference; availability varies by device/language.
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { status.setText("🎤 ऐकत आहे... आता बोला."); }
                public void onBeginningOfSpeech() { status.setText("तुमचा आवाज ऐकला... बोलणे पूर्ण करा."); }
                public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() { status.setText("शब्द समजून घेत आहे..."); }
                public void onError(int e) {
                    if (!running || speaking) return;
                    status.setText(errorMessage(e) + " पुन्हा प्रयत्न करत आहे...");
                    restartListening();
                }
                public void onResults(Bundle b) {
                    ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (a != null && !a.isEmpty()) repeat(a.get(0));
                    else { status.setText("शब्द समजले नाहीत. पुन्हा बोला."); restartListening(); }
                }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int e, Bundle b) {}
            });
            running = true; startButton.setEnabled(false); status.setText("Speech service तयार करत आहे..."); listenOnce();
        } catch (Exception ex) {
            status.setText("आवाज ओळख सुरू झाली नाही: " + ex.getClass().getSimpleName() + " - " + ex.getMessage());
            running = false;
        }
    }
    private void listenOnce() {
        if (!running || recognizer == null || speaking) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra("android.speech.extra.PREFER_OFFLINE", true);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, language.equals("mr-IN") ? "मराठीत बोला" : "Speak in English");
        try { recognizer.startListening(i); }
        catch (Exception e) { status.setText("ऐकणे सुरू झाले नाही: " + e.getMessage()); restartListening(); }
    }
    private String errorMessage(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_AUDIO: return "मायक्रोफोनमध्ये अडचण (ERROR_AUDIO).";
            case SpeechRecognizer.ERROR_CLIENT: return "Speech service मध्ये अडचण (ERROR_CLIENT).";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "मायक्रोफोन परवानगी मिळाली नाही.";
            case SpeechRecognizer.ERROR_NETWORK: return "नेटवर्कची गरज पडली किंवा सेवा उपलब्ध नाही.";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Speech service ला वेळ लागला.";
            case SpeechRecognizer.ERROR_NO_MATCH: return "आवाजातील शब्द ओळखता आले नाहीत.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Speech service व्यस्त आहे.";
            case SpeechRecognizer.ERROR_SERVER: return "Speech service कडून त्रुटी आली.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "आवाज ऐकू आला नाही. पुन्हा बोला.";
            default: return "आवाज ओळख त्रुटी क्रमांक " + code + ".";
        }
    }

    private void repeat(String words) {
        if (!running || words == null || words.trim().isEmpty()) { restartListening(); return; }
        speaking = true; heard.setText("मूल बोलले: " + words); babyReply.setText("Baby म्हणते: " + words);
        if (ttsReady) {
            tts.setLanguage(Locale.forLanguageTag(language));
            tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) { runOnUiThread(() -> { speaking = false; restartListening(); }); }
                @Override public void onError(String id) { runOnUiThread(() -> { speaking = false; restartListening(); }); }
            });
            tts.speak(words, TextToSpeech.QUEUE_FLUSH, null, "repeat-" + System.currentTimeMillis());
        } else { speaking = false; restartListening(); }
    }
    private void restartListening() { if (!running) return; if (recognizer != null) { try { recognizer.cancel(); } catch(Exception ignored) {} } status.postDelayed(this::listenOnce, 450); }
    private void stopListening() { running = false; speaking = false; if (recognizer != null) { try { recognizer.cancel(); recognizer.destroy(); } catch(Exception ignored) {} recognizer = null; } if (tts != null) tts.stop(); startButton.setEnabled(true); status.setText("ऐकणे थांबवले आहे."); }
    @Override protected void onPause() { super.onPause(); stopListening(); }
    @Override protected void onDestroy() { stopListening(); if (tts != null) tts.shutdown(); super.onDestroy(); }
}
